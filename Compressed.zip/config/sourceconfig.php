<?php
return [
    '33uu'=>'www.33uudy.com',
    'zuida'=>'www.zuidazy.com',
    'baiwan'=>'www.baiwanzy.com',
    'okzy'=>'www.okzyzy.cc',
    '131zy'=>'www.zy131.com',
    'qqzy'=>'caiji.000o.cc',
    'zuiyuanzy'=>'www.ziyuanpian.com',
    '1977zy'=>'www.go1977.com',
];