<?php
return array (
  'cc_max_times' => '5',
  'cc_url_time' => '5',
  'is_ss' => 'http://',
  'cc_admin_ip' => 
  array (
    0 => '127.0.0.1',
  ),
  'is_cc' => 'on',
);