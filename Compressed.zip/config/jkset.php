<?php
return array (
  '线路一' => 'http://api.lessh.cn/vip1.php?url=',
  '线路二' => 'http://api.lessh.cn/vip2.php?url=',
  '线路三' => 'http://api.lessh.cn/vip3.php?url=',
  '线路四' => 'http://api.lessh.cn/vip4.php?url=',
  '线路五' => 'http://api.lessh.cn/vip5.php?url=',
  '线路六' => 'http://api.lessh.cn/vip6.php?url=',
  '线路七' => 'http://api.lessh.cn/vip7.php?url=',
  '线路八' => 'http://api.lessh.cn/vip8.php?url=',
  '线路九' => 'http://api.lessh.cn/vip9.php?url=',
  '线路十' => 'http://api.lessh.cn/vip0.php?url=',
);