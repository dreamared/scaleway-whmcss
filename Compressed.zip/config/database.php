<?php
return array (
  'default' => 'mysql',
  'connections' => 
  array (
    'sqlite' => 
    array (
      'driver' => 'sqlite',
      'database' => 'freekan',
      'prefix' => '',
    ),
    'mysql' => 
    array (
      'driver' => 'mysql',
      'host' => 'localhost',
      'port' => 3306,
      'database' => 'freekan777',
      'username' => 'root',
      'password' => '1ue.com',
      'unix_socket' => '',
      'charset' => 'utf8',
      'collation' => 'utf8_unicode_ci',
      'prefix' => '',
      'strict' => true,
      'engine' => NULL,
    ),
    'pgsql' => 
    array (
      'driver' => 'pgsql',
      'host' => '127.0.0.1',
      'port' => '3306',
      'database' => 'freekan',
      'username' => 'root',
      'password' => '1ue.com',
      'charset' => 'utf8',
      'prefix' => '',
      'schema' => 'public',
      'sslmode' => 'prefer',
    ),
    'sqlsrv' => 
    array (
      'driver' => 'sqlsrv',
      'host' => '127.0.0.1',
      'port' => '3306',
      'database' => 'freekan',
      'username' => 'root',
      'password' => '1ue.com',
      'charset' => 'utf8',
      'prefix' => '',
    ),
  ),
  'cc' =>'/check.php?url=',
  'migrations' => 'migrations',
  'redis' => 
  array (
    'client' => 'predis',
    'default' => 
    array (
      'host' => '127.0.0.1',
      'password' => NULL,
      'port' => '6379',
      'database' => 0,
    ),
  ),
);