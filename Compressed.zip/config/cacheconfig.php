<?php
return array (
  'cacheswitch' => 'on',
  'autocache' => 'on',
  'cc' =>'/check.php?url=',
);