<?php
return array (
  'kamibuy' => 'http://www.sohu.com',
  'uservideo' => 'on',
  'uservideobk' => 'on',
  'qxbk' => 'on',
  'dybk' => 'on',
  'tvbk' => 'on',
  'zybk' => 'on',
  'dmbk' => 'on',
  'livebk' => 'on',
  'id' => 'eeeol.cn'
);