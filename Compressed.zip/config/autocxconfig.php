<?php
return array (
  'dizhi' => 'www.zy131.com',
  'is_autocx' => 'on',
  'dd' => 'ssl'
);