<?php
return array (
  'index_ad' => NULL,
  'play_top' => '<a href="http://tv.lessh.cn"><img src="https://ww1.sinaimg.cn/large/a15b4afegy1fmm2qom5o3j20sg06omxr.jpg" alt="首页广告" height="100px" width="900px"></a>',
  'play_in' => '<a href="http://tv.lessh.cn" target="_blank"><img src="/public/static/wapian/images/jz.jpg" alt="首页广告" height="100%" width="100%"></a>',
  'list_top' => '<a href="http://tv.lessh.cn"><img src="https://ww1.sinaimg.cn/large/a15b4afegy1fmm2qom5o3j20sg06omxr.jpg" alt="首页广告" height="100px" width="100%"></a>',
);