<?php
return array (
  'appid' => 'abcdefg',
  'appsecret' => 'abcdefh',
  'token' => '123',
  'wximg' => 'http://tv.lessh.cn/img/dow.png',
  'recontent' => '免vip观看',
  'reimg' => '/public/images/weixin.jpg',
);