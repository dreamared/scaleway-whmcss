<?php
return array (
  'appname' => 'FREEKAN',
  'appaz' => 'http://www.baidu.com',
  'appip' => 'https://ww1.sinaimg.cn/large/a15b4afegy1fmvhz1gq7kj20zk0zkn16.jpg',
  'appimg' => 'https://ww1.sinaimg.cn/large/a15b4afegy1fmof9l67s7j20bw0gmwi5.jpg',
  'appxc' => 'https://ww1.sinaimg.cn/large/a15b4afegy1fmzx22jjljj20eg03kglz.jpg',
  'appdh' => '客户端',
);